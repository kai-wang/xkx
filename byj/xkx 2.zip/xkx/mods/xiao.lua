require "wait"
require "tprint"
require "var"
require "bit"
require "socket"

module ("xiao", package.seeall)

local cxt = {}

init = function()
	EnableTriggerGroup("xiao_ask", false)
	EnableTriggerGroup("xiao", false)
	EnableTriggerGroup("xiao_fight", false)
	EnableTriggerGroup("xiao_halt", false)
end

main = function(f_ok, f_fail)
	cxt = {}
	cxt.f_ok = f_ok
	cxt.f_fail = f_fail
	var.xiao_start = 0
	var.xiao_retry_times = 0
	var.xiao_action = ""
	var.xiao_level = 1
	var.xiao_rewalk_times = 0
	var.walk_danger_level = 4

	EnableTriggerGroup("xiao_ask", true)
	EnableTriggerGroup("xiao", false)
	EnableTriggerGroup("xiao_fight", false)
	EnableTriggerGroup("xiao_halt", false)
	capture("set brief;fly lz;s;w;ask xiao about job", start, fail)
end


start = function()
	if(var.xiao_start ~= "1") then return fail() end

	EnableTriggerGroup("xiao_ask", false)
	EnableTriggerGroup("xiao", true)
	EnableTriggerGroup("xiao_fight", false)

	timer.stop("action")
	walk.sl(var.xiao_city, var.xiao_loc, notfound, rewalk, foundnpc)
end

fail = function()
	busy_test(function()
		Execute("fly lz;s;w;ask xiao about fail;fly wm")
		var.xiao_available_time = os.time() + 125
		exit()
		me.cleanup(function() call(cxt.f_fail) end)
	end)
end

done = function()
	var.xiao_available_time = os.time()
	exit()
	me.cleanup(function() call(cxt.f_ok) end)
end

rewalk = function()
	var.xiao_rewalk_times = tonumber(var.xiao_rewalk_times) + 1
	if(tonumber(var.xiao_rewalk_times) > 3) then 
		fail()
	else
		busy_test(function()
			Execute("fly wm;nw")
			timer.tick("action", 5, function() start() end)
		end)
	end
end

exit = function()
	EnableTriggerGroup("xiao_ask", false)
	EnableTriggerGroup("xiao", false)
	EnableTriggerGroup("xiao_fight", false)
	timer.stop("action")
end

foundnpc = function()
	var.xiao_found = true
	if(var.xiao_action == "�ܻ�" or var.xiao_action == "����") then
		if(var.xiao_killer_heal == "false") then
			startKill()
		else
			startTouxi()
		end
	--elseif(tonumber(var.xiao_level) <= 2) then
	--	startFight()
	else
		startFight()
	end
end

-- ���궼û�ҵ�
notfound = function()
	var.xiao_found = false
	fight.stop()
	Execute("halt")
	timer.stop("action")
	--���walkaround���껹û�ҵ�����retry��
	print("���껹û�ҵ�")
	busy_test(function()
		walk.walkaround(5, nil, rewalk, rewalk, foundnpc)
	end)
end

startFight = function()
	abort_busytest()
	timer.stop("action")
	local busy_list = me.profile.busy_list
	local attack_list = me.profile.attack_list3
	fight.prepare(busy_list, attack_list, escape)
	fight.start("fight shashou")
	EnableTriggerGroup("xiao_fight", true)
	EnableTriggerGroup("xiao_halt", true)
end

startKill = function()
	abort_busytest()
	timer.stop("action")
	local busy_list = me.profile.busy_list
	local attack_list = me.profile.attack_list2
	fight.prepare(busy_list, attack_list, escape)
	fight.start("fight shashou")
	EnableTriggerGroup("xiao_fight", true)
end

startTouxi = function()
	abort_busytest()
	timer.stop("action")
	local busy_list = me.profile.busy_list
	local attack_list = me.profile.attack_list2
	fight.prepare(busy_list, attack_list, escape)
	fight.start("touxi shashou")
	EnableTriggerGroup("xiao_fight", true)
end

fightend = function()
	EnableTriggerGroup("fight_end", false)
	if(var.xiao_action == "�ܻ�" or var.xiao_action == "����") then
		busy_test(function() 
			Execute("er;et;ef;")
			busy_test(function() fight.start("touxi shashou") end)
		end)
	else
		if(var.xiao_action == "����") then 
			Execute("ask shashou about ����")
		else
			busy_test(function() Execute("quan shashou") end)
		end
	end
end

fighthalt = function()
	if(var.xiao_action == "�ܻ�" or var.xiao_action == "����") then
		return
	else
		if(var.xiao_action == "����") then 
			fight.halt(function() Execute("ask shashou about ����") end)
		else
			fight.halt(function() Execute("quan shashou") end)
		end
	end
end

retry = function()
	EnableTriggerGroup("xiao_fight", false)
	me.updateHP(function()
		heal(function()
			timer.tick("action", 3, function()
				--Execute("look")
				var.xiao_retry_times = tonumber(var.xiao_retry_times) + 1
				print("retry times: " .. var.xiao_retry_times)
				if(tonumber(var.xiao_retry_times) > 6) then
					return fail()
				end
				busy_test(function()
					walk.walkaround(2, var.xiao_escape_dir, notfound, rewalk, foundnpc)
				end)
			end)
		--[[
			timer.tick("action", 3, function()
				Execute("look")
				var.xiao_retry_times = tonumber(var.xiao_retry_times) + 1
				print("retry times: " .. var.xiao_retry_times)
				if(tonumber(var.xiao_retry_times) > 10) then
					return fail()
				end
			end)
		]]--
		end)
	end)
end


heal = function(f_done)
	if(cxt.heal) then return end
	
	if(tonumber(var.hp_nl) > tonumber(var.hp_nl_max)) then
		Execute("halt;er;et;ef")
		cxt.heal = false
		call(f_done)
	else
		busy_test(function()
			dazuo.start(function()
				Execute("halt;er;ef;et")
				cxt.heal = false
				call(f_done)
			end)
		end)
	end
		
	--[[
	wait.make(function()
		cxt.heal = true
		Execute("yun cure")
		repeat
			local l, w = wait.regexp("^(> )*(��.*�����ˣ�)|(�㲢δ�ж���)|(�����ھ�����.*)$", 10)
			if(l ~= nil and l:match("�����ھ�����") ~= nil) then return fail() end
		until((l == nil) or (l:match("�㲢δ�ж�") ~= nil))
		
		print("�������")
		
		Execute("halt;er;et;yun heal")
		local l, w = wait.regexp("^(> )*(�㲢û�����ˣ�)|(���˹����).*$", 20)
		print("�������")
		
		if(tonumber(var.hp_nl) > tonumber(var.hp_nl_max)) then
			Execute("halt;er;et;ef")
			cxt.heal = false
			call(f_done)
		else
			busy_test(function()
				dazuo.start(function()
					Execute("halt;er;ef;et")
					cxt.heal = false
					call(f_done)
				end)
			end)
		end
	end)
	]]--
end

kill = function()
	abort_busytest()
	timer.stop("action")
	local busy_list = me.profile.busy_list
	local attack_list = me.profile.attack_list2
	fight.prepare(busy_list, attack_list, escape)
	fight.start("kill shashou")
	EnableTriggerGroup("xiao_fight", true)
end

escape = function()
	timer.tickonce("action", 3, function()
		Execute("halt;fly wm;nw;er;et;ef")
		me.cleanup(start)
	end)
end

-------- task ���ˣ���ԭ�ط�Χ�ڽ������Ϊ5�ı���-----------------------------------
search = function(name, line, wildcards)
	if(var.xiao_found == "true") then
		print("task ����" .. wildcards[2] .. "������")
		local dir = wildcards[2]
		dir = dir:gsub("��",""):gsub("��", ""):gsub("����", ""):gsub("��", "")
		var.xiao_escape_dir = dir
		timer.stop("action")
		var.xiao_found = false
		if(walk.stopped()) then searchKiller() end
	end
end

searchKiller = function()
	--DeleteTemporaryTriggers()
	timer.stop("action")
	Execute("halt")
	busy_test(function()
		print("�� " .. var.xiao_escape_dir .. " ��ʼwalkaround" )
		Execute("er;et;ef")
		walk.walkaround(3, var.xiao_escape_dir, notfound, rewalk, foundnpc)
	end)
end

finish = function()
	if(var.xiao_action == "�ܻ�") then
		Execute("look")
		fight.halt(function()
			Execute("get " .. var.xiao_npc_id)
			Execute("fly lz;s;w;give xiao " .. var.xiao_npc_id)
			done()
		end)
	elseif(var.xiao_action == "����") then
		busy_test(function()
			Execute("wield jian;wield dao;kantou corpse;fly lz;s;w;give xiao head")
			done()
		end)
	else
		busy_test(function()
			Execute("fly lz;s;w;ask xiao about finish")
			done()
		end)
	end
end


auto = function()
	--wait.make(function()
		local f = nil
		f = function()
			local t = tonumber(var.xiao_available_time) - os.time()
			print("�����ȴ�ms: " .. t)
			wait.make(function()
				if(t > 0) then wait.time(t) else wait.time(2) end
				me.useqn(function() double(function() main(f, f) end) end)
			end)
		end
		
		me.useqn(function() double(function() main(f, f) end) end)
	--end)
end

init()