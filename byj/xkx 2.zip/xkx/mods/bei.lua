require "wait"
require "tprint"
require "var"
require "bit"
require "socket"

module ("bei", package.seeall)

local cxt = {}
local task1 = dofile("worlds\\xkx\\mods\\task1.lua")
local task1_array = {}
retry_list = {10, 10, 15, 15, 20, 20, 30, 30}

main = function(f_ok, f_fail)
	cxt = {}
	cxt.f_ok = f_ok
	cxt.f_fail = f_fail
	
	var.walk_danger_level = 2
	EnableTriggerGroup("bei", true)
	Execute("set brief;fly wm;e;n;e;e;e;task;fly wm")
end

exit = function()
	walk.abort()
	fight.stop()
	ts.stop("task_walk")
	EnableTriggerGroup("bei", false)
	EnableTriggerGroup("bei_task1", false)
	
	Execute("halt;fly wm");
end


done = function()
	print("bei done")
	var.task_status = "done"
	var.task_end_time = os.time()
	if(var.double_bonus == "true") then var.task_available_time = os.time() end
	exit()
	call(cxt.f_ok)
end

fail = function()
	print("bei done")
	var.task_status = "fail"
	retry()
	exit()
	call(cxt.f_fail)
end

fail2 = function()
	print("bei done")
	var.task_status = "fail"
	----retry()
	exit()
	call(cxt.f_fail)
end

retry = function()
	local t = tonumber(var.task_retry_times)
	if(t > #retry_list) then 
		var.task_available_time = var.task_end_time 
	else
		var.task_available_time = os.time() + retry_list[t]
		var.task_retry_times = t + 1
	end
end

available = function()
	return (var.task_available_time == "") 
	or (os.time() >= tonumber(var.task_available_time))
end

reloc = function()
	Execute("fly wm")
	timer.tick("action", 10, function()
		Execute("u;loc " .. var.task_id)
	end)
end

start = function(name, line, wildcards)
	var.task_npc = wildcards[2]
	--ֱ�ӷŵ�id.lua�ļ���ȥ��
	--var.task_id = me.id .. "'s task"
	var.task_fullname = (var.task_id):gsub("^%l", string.upper)
	var.task_found = false
	var.task_retry_times = 1
	var.task_status = "start"
	var.task_escape_dir = ""
	
	parseAndLoc()
end

logtime = function(name, line, wildcards)
	local st = os.time()
	var.task_start_time = st
	var.task_available_time = st + 120	-- ��˫������£�2����һ��task
	var.task_end_time = st + getseconds(wildcards[2])
end

resume = function()
	var.task_found = false
	var.task_status = "start"
	var.task_escape_dir = ""
	
	if((tonumber(var.task_retry_times) % 2) > 0) then
		parseAndLoc()
	else
		gofortask()
	end
end

parseAndLoc = function()
	wait.make(function()
		EnableTriggerGroup("bei_task1", true)
		Execute("u;task1;set task1")
		local l, w = wait.regexp("^(> )*(������û���κ�ʹ����)|(�趨����������task1 = \"YES\")$")
		EnableTriggerGroup("bei_task1", false)
		if(l and string.match(l, "������û���κ�ʹ��")) then
			done()
		else
			local t1 = socket.gettime() * 1000
			local city = parse()
			local t2 = socket.gettime() * 1000
			print("����ʱ�� .. " .. math.floor(t2-t1) .. " ms")
			if(city == nil) then
				print("�Ҳ���ƥ��ĳ���")
				fail()
			else
				var.task_city = city
				Execute("loc " .. var.task_id)
			end
		end
	end)
end

location = function(name, line, wildcards)
	var.task_loc = wildcards[3]
	print(var.task_city .. " " .. var.task_loc .. " " .. var.task_npc)
	
	gofortask()
end

gofortask = function()
	local busy_list = me.profile.task_busy_list
	local attack_list = me.profile.task_attack_list
	local long_attack_list = me.profile.task_long_attack_list
	fight.prepare(busy_list, attack_list, escape, var.task_menpai)
	me.profile.powerup()
	--���slowwalk���껹û��stop��˵��û�ҵ�
	walk.sl(var.task_city, var.task_loc, bei.notfound, bei.fail, bei.foundnpc)
end

faint = function()
	var.faint_flag = true
	me.profile.reset_cd_status()
	if(var.me_status_ssf == "true" or var.me_status_poison == "true") then
		timer.reconnect(90, function() cleanup() end)
	end
end

-- ���궼û�ҵ�
notfound = function()
	var.task_found = false
	fight.stop()
	Execute("halt")
	--���walkaround���껹û�ҵ�����retry��
	print("���껹û�ҵ�")
	busy_test(function()
		walk.walkaround(5, nil, bei.fail, bei.fail, bei.foundnpc)
	end)
end

foundnpc = function()
	var.task_found = true
	if(var.task_auto_kill == "0") then
		walktask()
	else
		startFight()
	end
end

walktask = function()
	Execute("ask " .. var.task_id .. " about rumors")
	
	timer.tickonce("action", 1.5, function()
		if(var.task_status == "done" or fight.infight()) then return end
		Execute("halt;er;et;ef")
		walk.walkaround(2, nil, bei.notfound, bei.fail, bei.foundnpc)
	end)
end

startFight = function()
	abort_busytest()
	timer.stop("action")
	local busy_list = me.profile.task_busy_list
	local attack_list = me.profile.task_attack_list
	local long_attack_list = me.profile.task_long_attack_list
	fight.prepare(busy_list, attack_list, escape, var.task_menpai)
	fight.start("kill " .. var.task_id)
end

escape = function()
	timer.tickonce("action", 2, function()
		retry()
		me.cleanup(fail2)
	end)
end

-------- task ���ˣ���ԭ�ط�Χ�ڽ������Ϊ5�ı���-----------------------------------
search = function(name, line, wildcards)
	print("task ����" .. wildcards[3] .. "������")
	local dir = wildcards[3]
	dir = dir:gsub("��",""):gsub("��", ""):gsub("����", ""):gsub("��", "")
	var.task_escape_dir = dir
	timer.stop("action")
	if(walk.stopped()) then searchTask() end
end

searchTask = function()
	busy_test(function()
		print("�� " .. var.task_escape_dir .. " ��ʼwalkaround" )
		if(var.task_status == "done") then return end
		Execute("er;et;ef")
		walk.walkaround(3, var.task_escape_dir, bei.notfound, bei.fail, bei.foundnpc)
	end)
end

----����npc���ˣ��Ѷ���������------------------------------------
npcdie = function(name, line, wildcards)
	wait.make(function()
		walk.abort()
		fight.stop()
		var.task_status = "done"
		local l, w  = wait.regexp("^(> )*" .. var.task_npc .. "���ڵ��������˼��£��������������Ѫ�����ˣ�$", 5)
		if(l == nil) then
			cleanup()
		else
			busy_test(function()
				item.lookandget(bei.cleanup)
			end)
		end
	end)
end


----task��������ƺ���������ѧϰ����----------------------------
cleanup = function()
	busy_test(function()
		Execute("halt;fly wm;nw;er;et;ef")
		me.cleanup(done)
	end)
end

guaji = function()
	--wait.make(function()
		local f = nil
		f = function()
			local t = tonumber(var.task_available_time) - os.time()
			print("�����ȴ�ms: " .. t)
			wait.make(function()
				if(t > 0) then wait.time(t) end
				me.useqn(function() main(f, f) end)
			end)
		end
		
		me.useqn(function() main(f, f) end)
	--end)
end

-----------------------------------------------------------------------------------------------------------------------------
--------------------------------------�����ǽ���task1���--------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------------------
function task1_init(name, line, wildcards)
	var.task_npc = wildcards[2]
	print(var.task_npc)
	cxt.start = true
	cxt.matrix = {}
end

function log_task1(name, line, wildcards, style)
	local str = ""
	for i, v in ipairs(style) do
		if(RGBColourToName(v.textcolour) == "yellow") then
			str = str .. (v.text):gsub("#","1")
		else
			str = str .. (v.text):gsub("#","0")
		end
	end

	table.insert(cxt.matrix, str)
end

function parse()
	if(cxt.matrix == {}) then return end
	local str = table.concat(cxt.matrix, "\n")
	local array = stringToArray(str)

	if(array ~= nil) then
		return checkSimilarity(array)
	end
end

function checkSimilarity(v1)

	local words, score, maxscore  = {}, {}, 0
	for i, v in ipairs(task1_array) do
		--local v2 = stringToArray(v.desc)
		local v2 = v.array
		if(#v1 == #v2) then
			for j = 1, #v1 do
				if(score[j] == nil) then score[j] = 1000000000 end
				local dist0 = calculateDist(v1[j], v2[j], 0)
				local dist1 = calculateDist(v1[j], v2[j], 1)
				--local dist2 = calculateDist(v1[j], v2[j], 2)
				local dist3 = calculateDist(v2[j], v1[j], 1)
				--local dist4 = calculateDist(v2[j], v1[j], 2)
				local dist5 = calculateDist2(v1[j], v2[j], 1)
				--local dist6 = calculateDist2(v1[j], v2[j], 2)
				local dist7 = calculateDist2(v2[j], v1[j], 1)
				--local dist8 = calculateDist2(v2[j], v1[j], 2)
				local dist = math.min(dist0,dist1,dist3,dist5,dist7)
				--local dist = math.min(dist0,dist1,dist2,dist3,dist4,dist5,dist6,dist7,dist8)
				--local dist = dist0
				--print(v.city .. " dist :" .. dist)
				if(dist < score[j]) then
					score[j] = dist
					words[j] = v.city:sub(j*2-1, 2*j)
				end
			end
		end
	end

	local name = table.concat(words, "")
	print("��ƥ����֣� "..name)
	if(task1[name] ~= nil) then
		return name
	else
		local city, score = nil, 0
		for i, v in ipairs(task1) do
			if(#v.city == #name) then
				local lastmatch, m = 0, 0
				for j = 1, #words do
					if(v.city:sub(j*2-1, j*2) == words[j]) then
						if(lastmatch == 1) then m = m + 1.5 else m = m + 1 end
						lastmatch = 1
						if(m > score) then score = m city = v.city end
					end
					lastmatch = 0
				end
			end
		end
		print(city)
		return city
	end
end


function test(name)
	local words = {}
	for i = 1, #name do
		table.insert(words, name:sub(i*2-1, i*2))
	end
	
	local name = table.concat(words, "")
	print("��ƥ����֣� "..name)
	if(task1[name] ~= nil) then
		return name
	else
		local city, score = nil, 0
		for i, v in ipairs(task1) do
			if(#v.city == #name) then
				local lastmatch, m = 0, 0
				for j = 1, #words do
					if(v.city:sub(j*2-1, j*2) == words[j]) then
						if(j == 1) then 
							m = m + 1.2
						elseif(lastmatch == 1) then 
							m = m + 1.5 
						else
							m = m + 1 
						end
						lastmatch = 1
						if(m > score) then score = m city = v.city end
					end
					lastmatch = 0
				end
			end
		end
		print(city)
		return city
	end
end


function calculateDist(v1, v2, pos)
	local score = 0
	for i = 1, #v1 do
		if(v2[i] == nil) then v2[i] = 0 end
		--tprint(v1)
		local xor = bit.xor(bit.shl(v1[i], pos), v2[i])
		local dist = 0
		while(xor ~= 0) do
			dist = dist + 1
			xor = bit.band(xor, xor-1)
		end

		score = score + dist
	end
	return score
end

function calculateDist2(v1, v2, x)
	local v0 = {}
	for i = 1, x do
		v0[i] = 0
	end
	for i = x, #v1 do
		v0[i] = v1[i]
	end

	return calculateDist(v0, v2, 0)
end


function stringToArray(text)
	--if(task1[test] == nil) then return end

	local array = {}
	local tbl = utils.split(text, "\n")
	local len = #tbl[1]
	if(tbl[#tbl] == "") then tbl[#tbl] = nil end

	-------------ת�������ֺ�λ�����������һλ����17λ------------------------
	if(len == 32) then
		array[1], array[2] = {}, {}
		for i = 1, #tbl do
			table.insert(array[1], bit.shl(bit.tonumber(tbl[i]:sub(1,16), 2),1))
			table.insert(array[2], bit.shl(bit.tonumber(tbl[i]:sub(17,32), 2),1))
		end
	elseif(len == 33) then
		array[1], array[2] = {}, {}
		for i = 1, #tbl do
			table.insert(array[1], bit.tonumber(tbl[i]:sub(1,17), 2))
			table.insert(array[2], bit.shl(bit.tonumber(tbl[i]:sub(18,33), 2),1))
		end
	elseif(len == 34) then
		array[1], array[2] = {}, {}
		for i = 1, #tbl do
			table.insert(array[1], bit.tonumber(tbl[i]:sub(1,17), 2))
			table.insert(array[2], bit.tonumber(tbl[i]:sub(18,34), 2))
		end
	elseif(len == 48) then
		array[1], array[2], array[3] = {}, {}, {}
		for i = 1, #tbl do
			table.insert(array[1], bit.shl(bit.tonumber(tbl[i]:sub(1,16), 2),1))
			table.insert(array[2], bit.shl(bit.tonumber(tbl[i]:sub(17,32), 2),1))
			table.insert(array[3], bit.shl(bit.tonumber(tbl[i]:sub(33,48), 2),1))
		end
	elseif(len == 49) then
		array[1], array[2], array[3] = {}, {}, {}
		for i = 1, #tbl do
			table.insert(array[1], bit.tonumber(tbl[i]:sub(1,17), 2))
			table.insert(array[2], bit.shl(bit.tonumber(tbl[i]:sub(18,33), 2),1))
			table.insert(array[3], bit.shl(bit.tonumber(tbl[i]:sub(34,49), 2),1))
		end
	elseif(len == 50) then
		array[1], array[2], array[3] = {}, {}, {}
		for i = 1, #tbl do
			table.insert(array[1], bit.tonumber(tbl[i]:sub(1,17), 2))
			table.insert(array[2], bit.tonumber(tbl[i]:sub(18,34), 2))
			table.insert(array[3], bit.shl(bit.tonumber(tbl[i]:sub(35,50), 2),1))
		end
	elseif(len == 51) then
		array[1], array[2], array[3] = {}, {}, {}
		for i = 1, #tbl do
			table.insert(array[1], bit.tonumber(tbl[i]:sub(1,17), 2))
			table.insert(array[2], bit.tonumber(tbl[i]:sub(18,34), 2))
			table.insert(array[3], bit.tonumber(tbl[i]:sub(35,51), 2))
		end
	elseif(len == 64) then
		array[1], array[2], array[3], array[4] = {}, {}, {}, {}
		for i = 1, #tbl do
			table.insert(array[1], bit.tonumber(tbl[i]:sub(1,17), 2))
			table.insert(array[2], bit.shl(bit.tonumber(tbl[i]:sub(18,33), 2),1))
			table.insert(array[3], bit.shl(bit.tonumber(tbl[i]:sub(34,49), 2),1))
			table.insert(array[4], bit.shl(bit.tonumber(tbl[i]:sub(50,64), 2),1))
		end
	elseif(len == 65 or len == 66) then
		array[1], array[2], array[3], array[4] = {}, {}, {}, {}
		for i = 1, #tbl do
			table.insert(array[1], bit.tonumber(tbl[i]:sub(1,17), 2))
			table.insert(array[2], bit.shl(bit.tonumber(tbl[i]:sub(18,33), 2),1))
			table.insert(array[3], bit.shl(bit.tonumber(tbl[i]:sub(34,49), 2),1))
			table.insert(array[4], bit.shl(bit.tonumber(tbl[i]:sub(50,65), 2),1))
		end
	elseif(len == 67 or len == 68) then
		array[1], array[2], array[3], array[4] = {}, {}, {}, {}
		for i = 1, #tbl do
			table.insert(array[1], bit.tonumber(tbl[i]:sub(1,17), 2))
			table.insert(array[2], bit.shl(bit.tonumber(tbl[i]:sub(18,33), 2),1))
			table.insert(array[3], bit.shl(bit.tonumber(tbl[i]:sub(34,49), 2),1))
			table.insert(array[4], bit.shl(bit.tonumber(tbl[i]:sub(50,67), 2),1))
		end	
	end

	return array
end

---------�ֶ�����һ��task1������--------------------------
function save(name)
	var.task_city = name
	table.insert(task1, {["city"]=name, ["desc"]=table.concat(cxt.matrix, "\n")})
	local content = serialize.save("task1", task1)
	local file = io.open("worlds\\xkx\\mods\\task1.lua", "w")
	file:write("local " .. content)
	file:write("\r\nreturn task1")
	file:close()
	
	parse_array()
end

---------����ģת��������-----------------------------------
function parse_array()
	for i, v in ipairs(task1) do
		local tbl = {}
		tbl.city = v.city
		tbl.array = stringToArray(v.desc)
		table.insert(task1_array, tbl)
	end
end


parse_array()


