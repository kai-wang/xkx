require "wait"
require "tprint"
require "utils"
require "var"

module ("fight", package.seeall)

local context = {}

init = function()
	EnableTriggerGroup("fight", false)
	EnableTriggerGroup("fight_busy", false)
	timer.delete("fight")
end

prepare = function(busy_list, attack_list, f_escape, menpai)
	context.busy_list = busy_list
	context.attack_list = attack_list
	context.f_escape = f_escape
	--me.profile.powerup()
	context.infight = false
	context.escape = false
	context.halt = false
	context.menpai = menpai
	timer.create("fight", "fight", 0.5, function() perform_busy() end)
end

start = function(cmd)
	if(context.infight) then print("�Ѿ���ս����") return end
	
	EnableTriggerGroup("fight", true)
	context.infight = true
	context.escape = false
	context.halt = false
	--me.profile.powerup()
	if(me.profile.buff ~= nil) then me.profile.buff(context.menpai) end
	busy(cmd)
end

startnobuff = function(cmd)
	if(context.infight) then print("�Ѿ���ս����") return end
	
	EnableTriggerGroup("fight", true)
	context.infight = true
	context.escape = false
	context.halt = false
	--me.profile.powerup()
	--if(me.profile.buff ~= nil) then me.profile.buff() end
	busy(cmd)
end

stop = function()
	context.infight = false
	context.escape = false
	context.halt = false
	timer.stop("fight")
	print("fight stopped............")
	EnableTriggerGroup("fight", false)
end

perform_busy = function(cmd)
	if(context.busy_list == nil) then attack(cmd) return end

	for i, v in ipairs(context.busy_list) do
		local pfm = profile.pfm[v.i]
		if(pfm.cd_time ~= nil and (os.time() - tonumber(pfm.cd_time) > 30)) then pfm.cd = false end
		
		if(not pfm.cd) then
			if(cmd ~= nil) then
				Execute(cmd .. ";" .. v.action)
			else
				Execute(v.action)
			end
			pfm.inuse = true
			return
		end
	end

	--print("û��busy")
	attack(cmd)
end

perform_attack = function(cmd)

	for i, v in ipairs(context.attack_list) do
		local pfm = profile.pfm[v.i]
		if(pfm.cd_time ~= nil and (os.time() - tonumber(pfm.cd_time) > 30)) then pfm.cd = false end
		
		if(not pfm.cd) then 
			if(cmd ~= nil) then
				Execute(cmd .. ";" .. v.action)
			else
				Execute(v.action)
			end
			pfm.inuse = true
			return
		end
	end
end

busy = function(cmd)
	perform_busy(cmd)
	timer.tick("fight", 1, function() perform_busy(cmd) end)
end

recover = function()
	timer.tick("fight", 0.6, function() Execute("er;et;ef") end)
end

escape = function()
	timer.tick("fight", 0.1, function()
		if(context.escape == true) then return end
		context.escape = true 
		safeback("halt;fly wm", context.f_escape)
	end)
end

halt = function(f_done)
	--if(not context.halt) then context.halt = true end
	timer.tick("fight", 0.1, function()
		if(context.halt == true) then return end
		context.halt = true
		safehalt(f_done)
	end)
end

faint = function()
	fight.stop()
	me.profile.reset_cd_status()
	msg.broadcast("msg_fight_faint")
end

eatyao = function()

end

attack = function(cmd)
	perform_attack(cmd)
	timer.tick("fight", 1, function() perform_busy() end)
end

on_busy_success = function()
	timer.tick("fight", 0.3, attack)
end

on_busy_success_long = function()
	timer.tick("fight", 0.3, attack)
	EnableTriggerGroup("fight_busy", true)
end

on_escape_success = function()
	if(context.escape == true) then
		call(context.f_escape)
	end
	
	fight.stop()
end

on_perform_cd_ok = function(name, line, wildcards)
	--print("��Ϣ��� "..wildcards[2])
	me.profile.set_cd_status(wildcards[2], false)
end

on_perform = function(name, line, wildcards)
	--print("��Ϣ "..wildcards[2])
	me.profile.set_cd_status(wildcards[2], true)
end

infight = function()
	return context.infight ~= nil and context.infight == true
end

init()