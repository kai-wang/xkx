require "wait"
require "tprint"
require "utils"
require "var"

module ("study", package.seeall)

local cxt = {}

function done()
	EnableTriggerGroup("study", false)
	EnableTriggerGroup("study_check", false)
	me.profile.fight_wear(cxt.f_done)
end

function start(f_done)
	EnableTriggerGroup("study", true)
	EnableTriggerGroup("study_check", true)
	EnableTriggerGroup("HP", false)
	cxt.f_done = f_done
	
	wait.make(function()
		if(var.study_loc == nil or var.study_loc == "") then 
			done()
		else
			me.profile.int_wear(function()
				Execute(var.lll)
				Execute("hp")
			end)
		end
	end)
end

function continue()
	EnableTriggerGroup("study_check", true)
	Execute("er;et")
	Execute(var.lll)
	Execute("hp")
end

function givemoney()
	wait.make(function()
		Execute("give zhu 1 gold")
		local l, w = wait.regexp("(> )*(����ͬ��ָ����һЩ����д�ֵ����⡣)|(��û����ô��Ļƽ�)|(������û����������).*$")
		if(l:match("����ͬ��ָ��") == nil) then
			Execute("s;w;n;w;qukuan 1 gold")
			wait.time(5)
			Execute("e;s;e;n;give zhu 1 gold")
		else
			Execute("dazuo 10")
		end
	end)
end


function waitandtry()
	wait.make(function()
		EnableTriggerGroup("study_check", false)
		wait.time(10)
		EnableTriggerGroup("study_check", true)
		Execute("er;et;" .. var.me_dazuo)
	end)
end

function check(line, name, wildcards)
	local nl, nl_max = wildcards[4], wildcards[5]
	if(tonumber(nl) < tonumber(nl_max)*0.6) then
		EnableTriggerGroup("study_check", false)
		busy_test(function()
			Execute("er;et;" .. var.me_dazuo)
		end)
	else
		Execute(var.lll)
		EnableTriggerGroup("study_check", true)
		Execute("hp")
	end
end

module ("research", package.seeall)

local cxt = {}

function start(f_done)
	if(var.research_num == nil or tonumber(var.research_num) == 0) then var.research_num = 1
	else var.research_num = 1 + tonumber(tonumber(var.research_num) % #me.profile.research_list) end
	
	local skill = me.profile.research_list[tonumber(var.research_num)].skill
	study.start(function()
		Execute("fly wm;e;s;s;s;w;w;u;u;gamble big skill " .. skill .. " 2000")
		busy_test(function() Execute("fly wm") call(f_done) end )
	end)
	
end